from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum
from datetime import datetime
import uuid


class MarketLane(str, Enum):
    W2_SNIPER = "w2_sniper"
    CONTRACT = "contract"
    CONTRACT_TO_HIRE = "contract_to_hire"
    IGNORE = "ignore"


class JobStatus(str, Enum):
    NEW = "new"
    SCORED = "scored"
    APPLIED = "applied"
    INTERVIEW = "interview"
    OFFER = "offer"
    REJECTED = "rejected"
    PASSED = "passed"


class IntakeSource(str, Enum):
    MANUAL_PASTE = "manual_paste"
    EMAIL_FORWARD = "email_forward"
    URL_SCRAPE = "url_scrape"
    API = "api"


class ScoreBreakdown(BaseModel):
    skills_match: int = Field(ge=0, le=4, description="0-4: hard skill overlap")
    scope_impact: int = Field(ge=0, le=3, description="0-3: seniority/leadership match")
    pay_alignment: int = Field(ge=0, le=2, description="0-2: comp range vs target")
    gut_interest: int = Field(ge=0, le=1, default=0, description="0-1: manual override")
    total: int = Field(ge=0, le=10, default=0)
    skills_rationale: str = ""
    scope_rationale: str = ""
    pay_rationale: str = ""
    keyword_gaps: list[str] = []
    red_flags: list[str] = []
    bullshit_flag: bool = False
    bullshit_reason: str = ""
    recommended_resume: str = ""
    recommended_lane: MarketLane = MarketLane.IGNORE
    raw_analysis: str = ""


class CoverLetter(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    job_id: str
    variant: str  # "direct", "consultative", "brief"
    content: str
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())


class Job(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    title: str = ""
    company: str = ""
    url: str = ""
    source: str = ""
    intake_source: IntakeSource = IntakeSource.MANUAL_PASTE
    raw_jd: str = ""
    pay_range: str = ""
    market_lane: MarketLane = MarketLane.CONTRACT
    status: JobStatus = JobStatus.NEW
    score: Optional[ScoreBreakdown] = None
    cover_letters: list[CoverLetter] = []
    notes: str = ""
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    status_history: list[dict] = []

    def update_status(self, new_status: JobStatus):
        self.status_history.append({
            "from": self.status,
            "to": new_status,
            "at": datetime.now().isoformat()
        })
        self.status = new_status
        self.updated_at = datetime.now().isoformat()


class JobCreate(BaseModel):
    title: str = ""
    company: str = ""
    url: str = ""
    source: str = ""
    raw_jd: str
    pay_range: str = ""
    notes: str = ""


class JobUpdate(BaseModel):
    title: Optional[str] = None
    company: Optional[str] = None
    url: Optional[str] = None
    pay_range: Optional[str] = None
    status: Optional[JobStatus] = None
    market_lane: Optional[MarketLane] = None
    gut_interest: Optional[int] = None
    notes: Optional[str] = None


class AppConfig(BaseModel):
    w2_salary_min: int = 160000
    w2_salary_max: int = 220000
    contract_hourly_min: int = 85
    contract_hourly_max: int = 125
    deal_breakers: list[str] = [
        "must relocate",
        "on-site only outside DC metro",
        "requires TS/SCI",
    ]
    preferred_keywords: list[str] = [
        "data architecture",
        "analytics",
        "BI",
        "ERP",
        "financial systems",
        "data engineering",
        "Python",
        "SQL",
        "Tableau",
        "Power BI",
    ]
