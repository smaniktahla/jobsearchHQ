import os
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from datetime import datetime

from models import (
    Job, JobCreate, JobUpdate, JobStatus, MarketLane,
    IntakeSource, AppConfig, ScoreBreakdown
)
import storage
import scoring
from intake import process_intake

app = FastAPI(title="Job Search Command Center", version="1.0")


# === API Routes ===

@app.get("/api/jobs")
def list_jobs(status: str | None = None, lane: str | None = None):
    """List all jobs, optionally filtered by status or lane."""
    jobs = storage.load_all_jobs()
    if status:
        jobs = [j for j in jobs if j.status == status]
    if lane:
        jobs = [j for j in jobs if j.market_lane == lane]
    return [j.model_dump() for j in jobs]


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job = storage.load_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job.model_dump()


@app.post("/api/jobs")
def create_job(data: JobCreate):
    """Create a new job from pasted JD text."""
    job = Job(
        raw_jd=data.raw_jd,
        title=data.title,
        company=data.company,
        url=data.url,
        source=data.source,
        pay_range=data.pay_range,
        notes=data.notes,
        intake_source=IntakeSource.MANUAL_PASTE,
    )
    storage.save_job(job)
    return job.model_dump()


@app.post("/api/intake")
def intake_job(source: str = "manual_paste", raw_input: str = ""):
    """Process a job through the intake pipeline.
    
    Sources: manual_paste, url_scrape, email_forward
    """
    if not raw_input.strip():
        raise HTTPException(400, "No input provided")

    parsed = process_intake(source, raw_input)

    job = Job(
        raw_jd=parsed["raw_jd"],
        title=parsed.get("title", ""),
        company=parsed.get("company", ""),
        url=parsed.get("url", ""),
        source=parsed.get("source", source),
        pay_range=parsed.get("pay_range", ""),
        intake_source=IntakeSource(source) if source in IntakeSource.__members__.values() else IntakeSource.MANUAL_PASTE,
    )

    # Auto-extract metadata via Claude
    try:
        meta = scoring.extract_job_metadata(job.raw_jd)
        if meta:
            if not job.title and meta.get("title"):
                job.title = meta["title"]
            if not job.company and meta.get("company"):
                job.company = meta["company"]
            if not job.pay_range and meta.get("pay_range"):
                job.pay_range = meta["pay_range"]
            if meta.get("is_contract"):
                job.market_lane = MarketLane.CONTRACT
    except Exception:
        pass  # metadata extraction is best-effort

    storage.save_job(job)
    return job.model_dump()


@app.patch("/api/jobs/{job_id}")
def update_job(job_id: str, data: JobUpdate):
    job = storage.load_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")

    if data.title is not None:
        job.title = data.title
    if data.company is not None:
        job.company = data.company
    if data.url is not None:
        job.url = data.url
    if data.pay_range is not None:
        job.pay_range = data.pay_range
    if data.market_lane is not None:
        job.market_lane = data.market_lane
    if data.notes is not None:
        job.notes = data.notes
    if data.status is not None:
        job.update_status(data.status)
    if data.gut_interest is not None and job.score:
        job.score.gut_interest = data.gut_interest
        job.score.total = (
            job.score.skills_match + job.score.scope_impact +
            job.score.pay_alignment + job.score.gut_interest
        )

    job.updated_at = datetime.now().isoformat()
    storage.save_job(job)
    return job.model_dump()


@app.delete("/api/jobs/{job_id}")
def remove_job(job_id: str):
    if not storage.delete_job(job_id):
        raise HTTPException(404, "Job not found")
    return {"ok": True}


@app.post("/api/jobs/{job_id}/score")
def score_job(job_id: str):
    """Score a job using Claude API."""
    job = storage.load_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if not job.raw_jd.strip():
        raise HTTPException(400, "No JD text to score")

    try:
        result = scoring.score_job(job)
        job.score = result
        job.update_status(JobStatus.SCORED)
        if result.recommended_lane:
            job.market_lane = result.recommended_lane
        storage.save_job(job)
        return job.model_dump()
    except Exception as e:
        raise HTTPException(500, f"Scoring failed: {str(e)}")


@app.post("/api/jobs/{job_id}/cover-letters")
def generate_cover_letters(job_id: str):
    """Generate 3 cover letter variants for a scored job."""
    job = storage.load_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if not job.score:
        raise HTTPException(400, "Job must be scored first")

    try:
        letters = scoring.generate_cover_letters(job)
        job.cover_letters = letters
        job.updated_at = datetime.now().isoformat()
        storage.save_job(job)
        return [l.model_dump() for l in letters]
    except Exception as e:
        raise HTTPException(500, f"Cover letter generation failed: {str(e)}")


# === Config & Resume Management ===

@app.get("/api/config")
def get_config():
    return storage.load_config().model_dump()


@app.put("/api/config")
def update_config(config: AppConfig):
    storage.save_config(config)
    return config.model_dump()


@app.get("/api/resumes")
def list_resumes():
    """List available resume variants."""
    variants = ["director", "base", "contract", "full_history"]
    result = {}
    for v in variants:
        text = storage.load_resume_text(v)
        result[v] = {
            "loaded": bool(text),
            "length": len(text),
            "preview": text[:200] + "..." if len(text) > 200 else text,
        }
    return result


@app.put("/api/resumes/{variant}")
def upload_resume(variant: str, content: str = ""):
    """Upload/update resume text for a variant."""
    if variant not in ["director", "base", "contract", "full_history"]:
        raise HTTPException(400, "Invalid variant. Use: director, base, contract, full_history")
    storage.save_resume_text(variant, content)
    return {"ok": True, "variant": variant, "length": len(content)}


# === Dashboard Stats ===

@app.get("/api/stats")
def dashboard_stats():
    """Aggregate stats for the dashboard."""
    jobs = storage.load_all_jobs()
    by_status = {}
    by_lane = {}
    scores = []

    for j in jobs:
        by_status[j.status] = by_status.get(j.status, 0) + 1
        by_lane[j.market_lane] = by_lane.get(j.market_lane, 0) + 1
        if j.score:
            scores.append(j.score.total)

    return {
        "total": len(jobs),
        "by_status": by_status,
        "by_lane": by_lane,
        "avg_score": round(sum(scores) / len(scores), 1) if scores else 0,
        "score_distribution": {
            "high_8_10": len([s for s in scores if s >= 8]),
            "mid_5_7": len([s for s in scores if 5 <= s <= 7]),
            "low_0_4": len([s for s in scores if s < 5]),
        },
    }


# === Static Files (Frontend) ===

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def serve_root():
    return FileResponse("static/index.html")


if __name__ == "__main__":
    storage.ensure_dirs()
    port = int(os.environ.get("APP_PORT", 8093))
    uvicorn.run(app, host="0.0.0.0", port=port)
