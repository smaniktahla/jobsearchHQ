# Job Search Command Center

Locally hosted job search pipeline manager. Score job descriptions against your background using Claude API, get resume variant recommendations, and generate tailored cover letters.

## Quick Deploy (ubuntu-box)

```bash
cd ~/docker
git clone <this-repo> jobsearch  # or copy the folder
cd jobsearch

# Set your Anthropic API key
cp .env.example .env
nano .env  # add your key

# Launch
docker compose up -d --build

# Access at http://10.10.10.13:8093
```

## First Run Setup

1. Go to **Settings** → verify pay targets and deal-breakers
2. The **Full Employment History** resume is pre-loaded for scoring
3. Optionally upload the Director, Base, and Contract resume text variants (used for cover letter generation)
4. Start adding jobs via **Add Job** → paste JD text, URL, or forwarded email

## Architecture

- **Backend**: FastAPI (Python 3.11)
- **Frontend**: Vanilla HTML/JS/CSS (no build step)
- **Storage**: JSON files in `./data/` (no database)
- **AI**: Claude API (Sonnet) for scoring, metadata extraction, cover letter generation
- **Intake**: Pluggable — manual paste, URL scrape, email forward. Add new sources in `intake.py`

## Scoring Rubric

| Dimension | Range | What it measures |
|-----------|-------|-----------------|
| Skills Match | 0–4 | Hard skill overlap with JD |
| Scope/Impact | 0–3 | Seniority and leadership fit |
| Pay Alignment | 0–2 | Comp range vs your targets |
| Gut Interest | 0–1 | Your manual assessment |

**Lane assignment**: 8–10 → W2 Sniper, 5–7 → Contract, <5 → Ignore

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/jobs` | GET | List all jobs |
| `/api/intake` | POST | Add job via intake pipeline |
| `/api/jobs/{id}/score` | POST | Score a job with Claude |
| `/api/jobs/{id}/cover-letters` | POST | Generate 3 cover letter variants |
| `/api/config` | GET/PUT | App configuration |
| `/api/resumes` | GET | List loaded resume variants |
| `/api/resumes/{variant}` | PUT | Upload resume text |

## Data

All data in `./data/`:
- `jobs/` — one JSON file per job
- `resumes/` — resume text files (full_history.txt, director.txt, etc.)
- `config.json` — app settings

## Adding New Intake Sources

Edit `intake.py`:
1. Create a class implementing `IntakeHandler.parse()`
2. Register it in `INTAKE_HANDLERS`
3. The frontend tab is optional — the API accepts any registered source
